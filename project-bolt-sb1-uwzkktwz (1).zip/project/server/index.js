import express from 'express';
import cors from 'cors';
import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Database setup
const db = new sqlite3.Database(join(__dirname, 'database.db'));

// Initialize database tables
const initializeTables = () => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    balance REAL DEFAULT 0,
    username TEXT DEFAULT 'Player'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    image TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    image TEXT NOT NULL,
    price REAL NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS case_items (
    case_id INTEGER,
    item_id INTEGER,
    probability REAL,
    FOREIGN KEY (case_id) REFERENCES cases (id),
    FOREIGN KEY (item_id) REFERENCES items (id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    case_name TEXT,
    item_name TEXT,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);
};

// Initialize default user
const initializeUser = () => {
  db.get("SELECT * FROM users WHERE id = 'user1'", (err, row) => {
    if (!row) {
      db.run("INSERT INTO users (id, balance, username) VALUES ('user1', 1000, 'Player')", (err) => {
        if (err) console.error('Error creating default user:', err);
        else console.log('Default user created');
      });
    }
  });
};

// Routes

// Get user balance
app.get('/balance', (req, res) => {
  db.get("SELECT * FROM users WHERE id = 'user1'", (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (row) {
      res.json({ id: row.id, balance: row.balance, username: row.username });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });
});

// Get all cases
app.get('/cases', (req, res) => {
  db.all("SELECT * FROM cases", (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Get case items
app.get('/get-case-items', (req, res) => {
  const { caseId } = req.query;
  
  const query = `
    SELECT i.*, ci.probability 
    FROM items i 
    JOIN case_items ci ON i.id = ci.item_id 
    WHERE ci.case_id = ?
  `;
  
  db.all(query, [caseId], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Open case
app.post('/openCase', (req, res) => {
  const { caseId, userId } = req.body;
  
  if (!caseId || !userId) {
    return res.status(400).json({ error: 'Case ID and User ID are required' });
  }

  // Get case info
  db.get("SELECT * FROM cases WHERE id = ?", [caseId], (err, caseRow) => {
    if (err || !caseRow) {
      return res.status(404).json({ error: 'Case not found' });
    }

    // Get user balance
    db.get("SELECT * FROM users WHERE id = ?", [userId], (err, userRow) => {
      if (err || !userRow) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Check if user has enough balance
      if (userRow.balance < caseRow.price) {
        return res.status(400).json({ error: 'Insufficient balance' });
      }

      // Get case items with probabilities
      const query = `
        SELECT i.*, ci.probability 
        FROM items i 
        JOIN case_items ci ON i.id = ci.item_id 
        WHERE ci.case_id = ?
      `;
      
      db.all(query, [caseId], (err, items) => {
        if (err || items.length === 0) {
          return res.status(404).json({ error: 'No items found for this case' });
        }

        // Select random item based on probability
        const randomNum = Math.random();
        let cumulativeProbability = 0;
        let selectedItem = null;

        for (const item of items) {
          cumulativeProbability += item.probability;
          if (randomNum <= cumulativeProbability) {
            selectedItem = item;
            break;
          }
        }

        // Fallback to first item if none selected
        if (!selectedItem) {
          selectedItem = items[0];
        }

        // Update user balance
        const newBalance = userRow.balance - caseRow.price;
        db.run("UPDATE users SET balance = ? WHERE id = ?", [newBalance, userId], (err) => {
          if (err) {
            return res.status(500).json({ error: 'Failed to update balance' });
          }

          // Add to history
          const historyQuery = `
            INSERT INTO history (user_id, case_name, item_name, date) 
            VALUES (?, ?, ?, datetime('now'))
          `;
          
          db.run(historyQuery, [userId, caseRow.name, selectedItem.name], (err) => {
            if (err) {
              console.error('Error adding to history:', err);
            }

            // Return the result
            res.json({
              item: {
                id: selectedItem.id,
                name: selectedItem.name,
                image: selectedItem.image
              },
              newBalance: newBalance
            });
          });
        });
      });
    });
  });
});

// Add funds
app.post('/addFunds', (req, res) => {
  const { userId, amount } = req.body;
  
  if (!userId || !amount || amount <= 0) {
    return res.status(400).json({ error: 'Invalid user ID or amount' });
  }

  db.get("SELECT * FROM users WHERE id = ?", [userId], (err, row) => {
    if (err || !row) {
      return res.status(404).json({ error: 'User not found' });
    }

    const newBalance = row.balance + amount;
    db.run("UPDATE users SET balance = ? WHERE id = ?", [newBalance, userId], (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to update balance' });
      }
      
      res.json({ newBalance: newBalance });
    });
  });
});

// Get user history
app.get('/history', (req, res) => {
  const { userId } = req.query;
  
  if (!userId) {
    return res.status(400).json({ error: 'User ID is required' });
  }

  const query = `
    SELECT * FROM history 
    WHERE user_id = ? 
    ORDER BY date DESC 
    LIMIT 50
  `;
  
  db.all(query, [userId], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Admin routes
app.post('/admin/add-item', (req, res) => {
  const { name, image } = req.body;
  
  if (!name || !image) {
    return res.status(400).json({ error: 'Name and image are required' });
  }

  db.run("INSERT INTO items (name, image) VALUES (?, ?)", [name, image], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ id: this.lastID, name, image });
  });
});

app.post('/admin/add-case', (req, res) => {
  const { name, description, image, price, items } = req.body;
  
  if (!name || !description || !image || !price || !items) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  db.run("INSERT INTO cases (name, description, image, price) VALUES (?, ?, ?, ?)", 
    [name, description, image, price], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    
    const caseId = this.lastID;
    
    // Add case items
    const stmt = db.prepare("INSERT INTO case_items (case_id, item_id, probability) VALUES (?, ?, ?)");
    for (const item of items) {
      stmt.run([caseId, item.itemId, item.probability]);
    }
    stmt.finalize();
    
    res.json({ id: caseId, name, description, image, price });
  });
});

app.get('/admin/get-users', (req, res) => {
  db.all("SELECT * FROM users", (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

app.post('/admin/update-balance', (req, res) => {
  const { userId, balance } = req.body;
  
  if (!userId || balance === undefined) {
    return res.status(400).json({ error: 'User ID and balance are required' });
  }

  db.run("UPDATE users SET balance = ? WHERE id = ?", [balance, userId], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ success: true });
  });
});

app.get('/items', (req, res) => {
  db.all("SELECT * FROM items", (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Initialize and start server
db.serialize(() => {
  initializeTables();
  initializeUser();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});