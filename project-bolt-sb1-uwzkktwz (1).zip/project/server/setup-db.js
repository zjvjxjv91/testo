import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new sqlite3.Database(join(__dirname, 'database.db'));

// Sample data
const sampleItems = [
  { name: 'Dragon Sword', image: 'https://images.pexels.com/photos/1549558/pexels-photo-1549558.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Magic Crystal', image: 'https://images.pexels.com/photos/1076758/pexels-photo-1076758.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Golden Shield', image: 'https://images.pexels.com/photos/1030653/pexels-photo-1030653.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Fire Gem', image: 'https://images.pexels.com/photos/1054777/pexels-photo-1054777.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Ice Shard', image: 'https://images.pexels.com/photos/1407963/pexels-photo-1407963.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Lightning Bolt', image: 'https://images.pexels.com/photos/1002703/pexels-photo-1002703.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Ancient Rune', image: 'https://images.pexels.com/photos/1076758/pexels-photo-1076758.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { name: 'Mystic Orb', image: 'https://images.pexels.com/photos/1054777/pexels-photo-1054777.jpeg?auto=compress&cs=tinysrgb&w=400' },
];

const sampleCases = [
  {
    name: 'Legendary Case',
    description: 'Contains the rarest and most powerful items in the game',
    image: 'https://images.pexels.com/photos/1666779/pexels-photo-1666779.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 50
  },
  {
    name: 'Warrior Case',
    description: 'Perfect for fighters and melee combat enthusiasts',
    image: 'https://images.pexels.com/photos/1549558/pexels-photo-1549558.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 25
  },
  {
    name: 'Magic Case',
    description: 'Mystical items for spellcasters and magic users',
    image: 'https://images.pexels.com/photos/1076758/pexels-photo-1076758.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 30
  },
  {
    name: 'Starter Case',
    description: 'Great for beginners starting their adventure',
    image: 'https://images.pexels.com/photos/1030653/pexels-photo-1030653.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 10
  },
  {
    name: 'Elemental Case',
    description: 'Harness the power of fire, ice, and lightning',
    image: 'https://images.pexels.com/photos/1054777/pexels-photo-1054777.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 35
  },
  {
    name: 'Rare Artifacts',
    description: 'Ancient items with mysterious powers',
    image: 'https://images.pexels.com/photos/1407963/pexels-photo-1407963.jpeg?auto=compress&cs=tinysrgb&w=400',
    price: 45
  }
];

db.serialize(() => {
  console.log('Creating database tables...');
  
  // Create tables
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    balance REAL DEFAULT 0,
    username TEXT DEFAULT 'Player'
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    image TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    image TEXT NOT NULL,
    price REAL NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS case_items (
    case_id INTEGER,
    item_id INTEGER,
    probability REAL,
    FOREIGN KEY (case_id) REFERENCES cases (id),
    FOREIGN KEY (item_id) REFERENCES items (id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    case_name TEXT,
    item_name TEXT,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  )`);

  // Clear existing data
  db.run("DELETE FROM case_items");
  db.run("DELETE FROM items");
  db.run("DELETE FROM cases");

  // Insert sample items
  console.log('Inserting sample items...');
  const itemStmt = db.prepare("INSERT INTO items (name, image) VALUES (?, ?)");
  sampleItems.forEach(item => {
    itemStmt.run([item.name, item.image]);
  });
  itemStmt.finalize();

  // Insert sample cases
  console.log('Inserting sample cases...');
  const caseStmt = db.prepare("INSERT INTO cases (name, description, image, price) VALUES (?, ?, ?, ?)");
  sampleCases.forEach(case_ => {
    caseStmt.run([case_.name, case_.description, case_.image, case_.price]);
  });
  caseStmt.finalize();

  // Setup case-item relationships with probabilities
  console.log('Setting up case-item relationships...');
  
  // Legendary Case (Case ID: 1) - Rare items with low probability
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (1, 1, 0.15)"); // Dragon Sword
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (1, 2, 0.20)"); // Magic Crystal
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (1, 3, 0.25)"); // Golden Shield
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (1, 8, 0.40)"); // Mystic Orb

  // Warrior Case (Case ID: 2) - Combat items
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (2, 1, 0.30)"); // Dragon Sword
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (2, 3, 0.35)"); // Golden Shield
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (2, 7, 0.35)"); // Ancient Rune

  // Magic Case (Case ID: 3) - Magic items
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (3, 2, 0.25)"); // Magic Crystal
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (3, 4, 0.25)"); // Fire Gem
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (3, 8, 0.25)"); // Mystic Orb
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (3, 7, 0.25)"); // Ancient Rune

  // Starter Case (Case ID: 4) - Common items
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (4, 5, 0.40)"); // Ice Shard
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (4, 6, 0.35)"); // Lightning Bolt
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (4, 7, 0.25)"); // Ancient Rune

  // Elemental Case (Case ID: 5) - Elemental items
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (5, 4, 0.30)"); // Fire Gem
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (5, 5, 0.30)"); // Ice Shard
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (5, 6, 0.40)"); // Lightning Bolt

  // Rare Artifacts (Case ID: 6) - Rare items
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (6, 1, 0.25)"); // Dragon Sword
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (6, 2, 0.25)"); // Magic Crystal
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (6, 7, 0.25)"); // Ancient Rune
  db.run("INSERT INTO case_items (case_id, item_id, probability) VALUES (6, 8, 0.25)"); // Mystic Orb

  // Create default user
  db.run("INSERT OR REPLACE INTO users (id, balance, username) VALUES ('user1', 1000, 'Player')", (err) => {
    if (err) {
      console.error('Error creating default user:', err);
    } else {
      console.log('Default user created with $1000 balance');
    }
  });

  console.log('Database setup complete!');
});

db.close();