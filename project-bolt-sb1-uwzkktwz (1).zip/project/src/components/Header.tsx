import React from 'react';
import { User, Wallet, Settings } from 'lucide-react';
import { User as UserType } from '../types';

interface HeaderProps {
  user: UserType | null;
  onAddFunds: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, onAddFunds }) => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">CO</span>
              </div>
              <h1 className="text-xl font-bold text-white">Case Opening</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 bg-gray-800/50 rounded-lg px-4 py-2">
              <Wallet className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-semibold">
                ${user?.balance?.toFixed(2) || '0.00'}
              </span>
            </div>
            
            <button
              onClick={onAddFunds}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 transform hover:scale-105"
            >
              Add Funds
            </button>
            
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-gray-300" />
              </div>
              <span className="text-gray-300 font-medium">
                {user?.username || 'Player'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};