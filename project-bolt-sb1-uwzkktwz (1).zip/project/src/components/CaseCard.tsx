import React from 'react';
import { Case } from '../types';
import { ArrowRight, Sparkles } from 'lucide-react';

interface CaseCardProps {
  case: Case;
  onOpen: (caseData: Case) => void;
  userBalance: number;
}

export const CaseCard: React.FC<CaseCardProps> = ({ case: caseData, onOpen, userBalance }) => {
  const canAfford = userBalance >= caseData.price;

  return (
    <div className="group relative bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 border border-gray-700 hover:border-purple-500/50">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      
      <div className="relative">
        <div className="aspect-square w-full overflow-hidden">
          <img
            src={caseData.image}
            alt={caseData.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
        </div>
        
        <div className="p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-bold text-white group-hover:text-purple-300 transition-colors">
              {caseData.name}
            </h3>
            <Sparkles className="w-5 h-5 text-yellow-400 opacity-60 group-hover:opacity-100 transition-opacity" />
          </div>
          
          <p className="text-gray-400 text-sm mb-4 line-clamp-2">
            {caseData.description}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-green-400">
                ${caseData.price.toFixed(2)}
              </span>
            </div>
            
            <button
              onClick={() => onOpen(caseData)}
              disabled={!canAfford}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 transform ${
                canAfford
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white hover:scale-105 shadow-lg hover:shadow-purple-500/25'
                  : 'bg-gray-700 text-gray-400 cursor-not-allowed'
              }`}
            >
              <span>{canAfford ? 'Open' : 'Insufficient Funds'}</span>
              {canAfford && <ArrowRight className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};