import React, { useState, useEffect } from 'react';
import { User, Calendar, Package, TrendingUp } from 'lucide-react';
import { User as UserType, HistoryEntry } from '../types';

interface ProfilePageProps {
  user: UserType | null;
  fetchHistory: () => Promise<HistoryEntry[]>;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ user, fetchHistory }) => {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    setLoading(true);
    const historyData = await fetchHistory();
    setHistory(historyData);
    setLoading(false);
  };

  const stats = {
    totalOpened: history.length,
    totalSpent: history.length * 10, // Approximation
    favoriteCase: 'Legendary Case',
    winRate: '78%',
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-2xl p-8 border border-gray-700">
        <div className="flex items-center space-x-6">
          <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
            <User className="w-12 h-12 text-white" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">
              {user?.username || 'Player'}
            </h1>
            <div className="flex items-center space-x-4 text-gray-400">
              <span>Member since 2024</span>
              <span>•</span>
              <span>Level 12</span>
            </div>
            <div className="mt-4 flex items-center space-x-2">
              <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm font-medium">
                Balance: ${user?.balance?.toFixed(2) || '0.00'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-2">
            <Package className="w-8 h-8 text-blue-400" />
            <span className="text-2xl font-bold text-white">{stats.totalOpened}</span>
          </div>
          <p className="text-gray-400 text-sm">Cases Opened</p>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-green-400" />
            <span className="text-2xl font-bold text-white">${stats.totalSpent}</span>
          </div>
          <p className="text-gray-400 text-sm">Total Spent</p>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="w-8 h-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">{stats.winRate}</span>
          </div>
          <p className="text-gray-400 text-sm">Win Rate</p>
        </div>

        <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
          <div className="flex items-center justify-between mb-2">
            <User className="w-8 h-8 text-yellow-400" />
            <span className="text-lg font-bold text-white">12</span>
          </div>
          <p className="text-gray-400 text-sm">Level</p>
        </div>
      </div>

      {/* Opening History */}
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-6">Opening History</h2>
        
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-8">
            <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No cases opened yet</p>
            <p className="text-gray-500 text-sm mt-2">Start opening cases to see your history here</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {history.map((entry) => (
              <div
                key={entry.id}
                className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Package className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">{entry.item_name}</p>
                    <p className="text-gray-400 text-sm">from {entry.case_name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-gray-400 text-sm">
                    {new Date(entry.date).toLocaleDateString()}
                  </p>
                  <p className="text-gray-500 text-xs">
                    {new Date(entry.date).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};