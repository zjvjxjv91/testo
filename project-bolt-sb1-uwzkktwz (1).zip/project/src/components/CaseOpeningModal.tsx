import React, { useState, useEffect } from 'react';
import { X, Trophy, Sparkles } from 'lucide-react';
import { Case, Item, CaseOpenResult } from '../types';

interface CaseOpeningModalProps {
  isOpen: boolean;
  onClose: () => void;
  case: Case | null;
  onOpenCase: (caseId: number) => Promise<CaseOpenResult | null>;
  getCaseItems: (caseId: number) => Promise<Item[]>;
}

export const CaseOpeningModal: React.FC<CaseOpeningModalProps> = ({
  isOpen,
  onClose,
  case: selectedCase,
  onOpenCase,
  getCaseItems,
}) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [wonItem, setWonItem] = useState<Item | null>(null);
  const [caseItems, setCaseItems] = useState<Item[]>([]);
  const [animationItems, setAnimationItems] = useState<Item[]>([]);
  const [animationOffset, setAnimationOffset] = useState(0);

  useEffect(() => {
    if (isOpen && selectedCase) {
      loadCaseItems();
    }
  }, [isOpen, selectedCase]);

  const loadCaseItems = async () => {
    if (!selectedCase) return;
    
    const items = await getCaseItems(selectedCase.id);
    setCaseItems(items);
    
    // Create animation items by repeating the case items
    const repeatedItems = [];
    for (let i = 0; i < 20; i++) {
      repeatedItems.push(...items);
    }
    setAnimationItems(repeatedItems);
  };

  const handleOpenCase = async () => {
    if (!selectedCase || isAnimating) return;

    setIsAnimating(true);
    setWonItem(null);
    setAnimationOffset(0);

    // Start the animation
    const animationDuration = 3000; // 3 seconds
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / animationDuration, 1);
      
      // Easing function for smooth deceleration
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const finalOffset = 1500 + Math.random() * 200; // Random final position
      
      setAnimationOffset(easeOut * finalOffset);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        // Animation complete, open the case
        revealPrize();
      }
    };
    
    requestAnimationFrame(animate);
  };

  const revealPrize = async () => {
    if (!selectedCase) return;
    
    const result = await onOpenCase(selectedCase.id);
    if (result) {
      setWonItem(result.item);
    }
    setIsAnimating(false);
  };

  if (!isOpen || !selectedCase) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden border border-gray-700 shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <img
              src={selectedCase.image}
              alt={selectedCase.name}
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div>
              <h2 className="text-2xl font-bold text-white">{selectedCase.name}</h2>
              <p className="text-gray-400">${selectedCase.price.toFixed(2)}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Animation Container */}
          <div className="relative mb-8">
            <div className="bg-gray-800 rounded-xl p-4 overflow-hidden">
              <div className="relative h-32 flex items-center">
                {/* Center indicator */}
                <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-500 to-pink-500 transform -translate-x-1/2 z-10"></div>
                <div className="absolute left-1/2 top-1/2 w-6 h-6 bg-white rounded-full transform -translate-x-1/2 -translate-y-1/2 z-10 shadow-lg"></div>
                
                {/* Items slider */}
                <div
                  className="flex space-x-4 transition-transform duration-300 ease-out"
                  style={{
                    transform: `translateX(-${animationOffset}px)`,
                    willChange: 'transform',
                  }}
                >
                  {animationItems.map((item, index) => (
                    <div
                      key={index}
                      className="flex-shrink-0 w-24 h-24 bg-gray-700 rounded-lg flex items-center justify-center border-2 border-gray-600"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Result Display */}
          {wonItem && (
            <div className="text-center mb-6">
              <div className="inline-flex items-center space-x-3 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl p-6 border border-purple-500/30">
                <Trophy className="w-12 h-12 text-yellow-400" />
                <div>
                  <h3 className="text-2xl font-bold text-white mb-1">Congratulations!</h3>
                  <p className="text-lg text-purple-300">You won: {wonItem.name}</p>
                </div>
                <Sparkles className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
          )}

          {/* Open Button */}
          <div className="flex justify-center">
            <button
              onClick={handleOpenCase}
              disabled={isAnimating}
              className={`px-8 py-4 rounded-xl font-bold text-lg transition-all duration-200 transform ${
                isAnimating
                  ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white hover:scale-105 shadow-lg hover:shadow-purple-500/25'
              }`}
            >
              {isAnimating ? 'Opening...' : wonItem ? 'Open Another' : 'Open Case'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};