import { useState, useEffect } from 'react';
import { User, Case, Item, HistoryEntry, CaseOpenResult } from '../types';

const API_BASE = 'http://localhost:3001';

export const useApi = () => {
  const [user, setUser] = useState<User | null>(null);
  const [cases, setCases] = useState<Case[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchUser = async () => {
    try {
      const response = await fetch(`${API_BASE}/balance`);
      const data = await response.json();
      setUser(data);
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const fetchCases = async () => {
    try {
      const response = await fetch(`${API_BASE}/cases`);
      const data = await response.json();
      setCases(data);
    } catch (error) {
      console.error('Error fetching cases:', error);
    }
  };

  const openCase = async (caseId: number): Promise<CaseOpenResult | null> => {
    try {
      const response = await fetch(`${API_BASE}/openCase`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ caseId, userId: 'user1' }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to open case');
      }
      
      const result = await response.json();
      setUser(prev => prev ? { ...prev, balance: result.newBalance } : null);
      return result;
    } catch (error) {
      console.error('Error opening case:', error);
      return null;
    }
  };

  const fetchHistory = async (): Promise<HistoryEntry[]> => {
    try {
      const response = await fetch(`${API_BASE}/history?userId=user1`);
      return await response.json();
    } catch (error) {
      console.error('Error fetching history:', error);
      return [];
    }
  };

  const addFunds = async (amount: number) => {
    try {
      const response = await fetch(`${API_BASE}/addFunds`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: 'user1', amount }),
      });
      
      const result = await response.json();
      setUser(prev => prev ? { ...prev, balance: result.newBalance } : null);
    } catch (error) {
      console.error('Error adding funds:', error);
    }
  };

  const getCaseItems = async (caseId: number): Promise<Item[]> => {
    try {
      const response = await fetch(`${API_BASE}/get-case-items?caseId=${caseId}`);
      return await response.json();
    } catch (error) {
      console.error('Error fetching case items:', error);
      return [];
    }
  };

  useEffect(() => {
    const initializeData = async () => {
      setLoading(true);
      await Promise.all([fetchUser(), fetchCases()]);
      setLoading(false);
    };

    initializeData();
  }, []);

  return {
    user,
    cases,
    loading,
    openCase,
    fetchHistory,
    addFunds,
    getCaseItems,
    refreshUser: fetchUser,
    refreshCases: fetchCases,
  };
};