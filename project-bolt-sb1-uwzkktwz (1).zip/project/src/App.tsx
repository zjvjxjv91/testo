import React, { useState } from 'react';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { CaseCard } from './components/CaseCard';
import { CaseOpeningModal } from './components/CaseOpeningModal';
import { ProfilePage } from './components/ProfilePage';
import { AddFundsModal } from './components/AddFundsModal';
import { useApi } from './hooks/useApi';
import { Case } from './types';
import { Package, Sparkles, TrendingUp } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('main');
  const [selectedCase, setSelectedCase] = useState<Case | null>(null);
  const [showCaseModal, setShowCaseModal] = useState(false);
  const [showAddFundsModal, setShowAddFundsModal] = useState(false);

  const {
    user,
    cases,
    loading,
    openCase,
    fetchHistory,
    addFunds,
    getCaseItems,
  } = useApi();

  const handleOpenCase = (caseData: Case) => {
    setSelectedCase(caseData);
    setShowCaseModal(true);
  };

  const handleCloseModal = () => {
    setShowCaseModal(false);
    setSelectedCase(null);
  };

  const handleAddFunds = (amount: number) => {
    addFunds(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-500 mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <Header user={user} onAddFunds={() => setShowAddFundsModal(true)} />
      
      <main className="pt-4 pb-20">
        {activeTab === 'main' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Hero Section */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
                Open Epic Cases
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Discover rare items and legendary rewards
              </p>
              <div className="flex justify-center space-x-8 text-center">
                <div className="flex items-center space-x-2">
                  <Package className="w-8 h-8 text-purple-400" />
                  <span className="text-white font-semibold">Premium Cases</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Sparkles className="w-8 h-8 text-yellow-400" />
                  <span className="text-white font-semibold">Rare Items</span>
                </div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-8 h-8 text-green-400" />
                  <span className="text-white font-semibold">Fair Odds</span>
                </div>
              </div>
            </div>

            {/* Cases Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {cases.map((caseItem) => (
                <CaseCard
                  key={caseItem.id}
                  case={caseItem}
                  onOpen={handleOpenCase}
                  userBalance={user?.balance || 0}
                />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'weekly' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center py-16">
              <Package className="w-24 h-24 text-gray-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">Weekly Specials</h2>
              <p className="text-gray-400">Coming soon! Special weekly cases and promotions.</p>
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <ProfilePage user={user} fetchHistory={fetchHistory} />
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <ProfilePage user={user} fetchHistory={fetchHistory} />
          </div>
        )}
      </main>

      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      <CaseOpeningModal
        isOpen={showCaseModal}
        onClose={handleCloseModal}
        case={selectedCase}
        onOpenCase={openCase}
        getCaseItems={getCaseItems}
      />

      <AddFundsModal
        isOpen={showAddFundsModal}
        onClose={() => setShowAddFundsModal(false)}
        onAddFunds={handleAddFunds}
      />
    </div>
  );
}

export default App;