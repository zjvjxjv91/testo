export interface User {
  id: string;
  balance: number;
  username: string;
  avatar?: string;
}

export interface Item {
  id: number;
  name: string;
  image: string;
  rarity?: string;
  value?: number;
}

export interface Case {
  id: number;
  name: string;
  description: string;
  image: string;
  price: number;
}

export interface CaseItem {
  case_id: number;
  item_id: number;
  item: Item;
  probability: number;
}

export interface HistoryEntry {
  id: number;
  user_id: string;
  case_name: string;
  item_name: string;
  date: string;
}

export interface CaseOpenResult {
  item: Item;
  newBalance: number;
}